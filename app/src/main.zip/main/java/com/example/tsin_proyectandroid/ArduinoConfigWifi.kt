package com.example.tsin_proyectandroid

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.tsin_proyectandroid.ui.theme.TSIN_ProyectAndroidTheme

class ArduinoConfigWifi : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TSIN_ProyectAndroidTheme {
                ArduinoConfigWifiScreen(onBackPressed = { finish() })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArduinoConfigWifiScreen(onBackPressed: () -> Unit) {
    val scrollBehavior = TopAppBarDefaults.pinnedScrollBehavior(rememberTopAppBarState())

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                ),
                title = {
                    Text(
                        "Configuración de Arduino Wifi"
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackPressed) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Regresar"
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        }
    ) { innerPadding ->
        WifiForm(modifier = Modifier.padding(innerPadding))
    }
}

@Composable
fun WifiForm(modifier: Modifier = Modifier) {
    var textFields by remember { mutableStateOf(List(6) { "" }) }
    var expanded by remember { mutableStateOf(false) }
    var selectedOption by remember { mutableStateOf("Linea de orientación") }
    val options = listOf("Horizontal", "Vertical")
    val fieldLabels = listOf("Alias", "Ubicación", "Factor de conversión de metros por pixel", "Altura del cuadro delimitador de referencia", "Linea de posición", "Altura de la linea de posición")

    Column(modifier = modifier.padding(16.dp)) {
        textFields.forEachIndexed { index, text ->
            OutlinedTextField(
                value = text,
                onValueChange = { newText ->
                    textFields = textFields.toMutableList().also { it[index] = newText }
                },
                label = { Text(fieldLabels[index]) },
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box {
            Button(onClick = { expanded = true }) {
                Text(selectedOption)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { option ->
                    DropdownMenuItem(text = { Text(option) }, onClick = {
                        selectedOption = option
                        expanded = false
                    })
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {  }, modifier = Modifier.fillMaxWidth()) {
            Text("Guardar")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun WifiFormPreview() {
    TSIN_ProyectAndroidTheme {
        ArduinoConfigWifiScreen(onBackPressed = {})
    }
}
