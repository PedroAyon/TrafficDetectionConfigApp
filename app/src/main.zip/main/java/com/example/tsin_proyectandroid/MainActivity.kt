package com.example.tsin_proyectandroid
import com.example.tsin_proyectandroid.ui.theme.TSIN_ProyectAndroidTheme

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TSIN_ProyectAndroidTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = { TopBar() }
                ) { innerPadding ->
                    Content(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopBar() {
    TopAppBar(
        title = { Text("TrafficCam Config") }
    )
}

@Composable
fun SearchBar(
    isWifiEnabled: Boolean,
    onToggleWifiBluetooth: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchText by remember { mutableStateOf("") }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextField(
            value = searchText,
            onValueChange = { searchText = it },
            placeholder = { Text("Buscar...") },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = "Buscar")
            },
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        WifiBluetoothToggle(isWifiEnabled, onToggleWifiBluetooth)
    }
}

@Composable
fun WifiBluetoothToggle(isWifiEnabled: Boolean, onToggle: () -> Unit) {
    Surface(
        modifier = Modifier
            .size(48.dp),
        shape = CircleShape,
        color = if (isWifiEnabled) Color(0xFF42A5F5) else Color(0xFF26A69A),
        shadowElevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .clickable { onToggle() },
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AnimatedContent(
                targetState = isWifiEnabled,
                transitionSpec = {
                    fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
                }
            ) { wifiOn ->
                Icon(
                    imageVector = if (wifiOn) Icons.Filled.Wifi else Icons.Filled.Bluetooth,
                    contentDescription = if (wifiOn) "Wi-Fi Enabled" else "Bluetooth Enabled",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
fun Content(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var isWifiEnabled by remember { mutableStateOf(true) }
    var dispositivos by remember { mutableStateOf<List<String>?>(null) }

    LaunchedEffect(isWifiEnabled) {
        dispositivos = null
        delay(1000)
        dispositivos = if (isWifiEnabled) {
            listOf("WiFi 1", "WiFi 2", "WiFi 3")
        } else {
            listOf("BT 1", "BT 2", "BT 3")
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        SearchBar(
            isWifiEnabled = isWifiEnabled,
            onToggleWifiBluetooth = { isWifiEnabled = !isWifiEnabled }
        )

        if (dispositivos == null) {
            CircularProgressIndicator()
        } else if (dispositivos!!.isEmpty()) {
            Text("¿No hay dispositivos?")
        } else {
            dispositivos!!.forEachIndexed { index, dispositivo ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .clickable {
                            val intent = if (isWifiEnabled) {
                                Intent(context, ArduinoConfigWifi::class.java)
                            } else {
                                Intent(context, ArduinoConfigBluetooth::class.java)
                            }
                            context.startActivity(intent)
                        },
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Text(
                        text = "Card #${index + 1}: $dispositivo",
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewContent() {
    TSIN_ProyectAndroidTheme {
        Scaffold(
            topBar = { TopBar() }
        ) {
            Content(Modifier.padding(it))
        }
    }
}